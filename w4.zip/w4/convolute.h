#pragma once
// Workshop 4 - Convolution Application
// convolute.h
// chris Szalwinski

#include "corona.h"


corona::Image* convolute(corona::Image*);
corona::Image* convolute(corona::Image*, const int, int&);